import torch
from mobilenetv2_imag import mobilenet_v2


path_refine='./mobilenev2_nodec_w_1.996_par_27.13_FLOPs_43.65.tar'
path_resume='./checkpoint_mobilenetv2_top1_66_top5_87.21.pth.tar'


checkpoint = torch.load(path_refine)
model = mobilenet_v2(inverted_residual_setting=checkpoint['cfg'])
model.load_state_dict(checkpoint['state_dict'])

print("=> loading checkpoint '{}'".format(path_resume))

checkpoint = torch.load(path_resume)
best_prec1 = checkpoint['best_prec1']
print(best_prec1)
model.load_state_dict(checkpoint['state_dict'], strict=False)
model.cuda()
print("=> loaded checkpoint '{}' (epoch {})"
      .format(path_resume, checkpoint['epoch']))

